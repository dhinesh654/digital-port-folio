var body = document.querySelector("body");
var button = document.getElementById("darkmode-btn");

button.onclick = function() {
    body.classList.toggle("darkmode");}